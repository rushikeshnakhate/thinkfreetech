<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'تقرير المنتجات التي تمت مشاهدتها';

// Text
$_['text_extension']   = 'الموديولات';
$_['text_edit']        = 'تحرير';
$_['text_success']     = 'تم التعديل !';

// Column
$_['column_name']      = 'اسم المنتج';
$_['column_model']     = 'النوع';
$_['column_viewed']    = 'عدد المشاهدات';
$_['column_percent']   = 'النسبة';

// Entry
$_['entry_status']     = 'الحالة';
$_['entry_sort_order'] = 'ترتيب الفرز';

// Error
$_['error_permission']  = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
