<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']       = 'موديول حر - HTML Content';

// Text
$_['text_extension']      = 'الموديولات';
$_['text_success']        = 'تم التعديل !';
$_['text_edit']           = 'تحرير';

// Entry
$_['entry_name']          = 'اسم الموديول';
$_['entry_title']         = 'العنوان';
$_['entry_description']   = 'الوصف';
$_['entry_status']        = 'الحالة';

// Error
$_['error_permission']    = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
$_['error_name']       = 'اسم الموديول يجب ان يكون بين 3 و 64 حرف !';
